#include <stdio.h>

#include <stdlib.h>



void embed_image(const char *elf_file, const char *image_file, const char *output_file) {

    FILE *elf_fp = fopen(elf_file, "rb");

    FILE *image_fp = fopen(image_file, "rb");

    FILE *output_fp = fopen(output_file, "wb");



    if (!elf_fp || !image_fp || !output_fp) {

        fprintf(stderr, "Error opening files.\n");

        exit(EXIT_FAILURE);

    }



    // Copy the ELF file to the output

    char buffer[4096];

    size_t bytes;

    while ((bytes = fread(buffer, 1, sizeof(buffer), elf_fp)) > 0) {

        fwrite(buffer, 1, bytes, output_fp);

    }



    // Append the image data to the output

    while ((bytes = fread(buffer, 1, sizeof(buffer), image_fp)) > 0) {

        fwrite(buffer, 1, bytes, output_fp);

    }



    fclose(elf_fp);

    fclose(image_fp);

    fclose(output_fp);



    printf("Image embedded successfully into %s\n", output_file);

}



int main(int argc, char *argv[]) {

    if (argc != 4) {

        fprintf(stderr, "Usage: %s <elf_file> <image_file> <output_file>\n", argv[0]);

        return EXIT_FAILURE;

    }



    embed_image(argv[1], argv[2], argv[3]);

    return EXIT_SUCCESS;

}

